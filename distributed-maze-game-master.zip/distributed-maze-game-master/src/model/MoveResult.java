package model;

public enum MoveResult {
	SUCCESS,
	INVALID_PLAYER_ID,
	INVALID_POSITION,
	INVALID_DIRECTION
}
