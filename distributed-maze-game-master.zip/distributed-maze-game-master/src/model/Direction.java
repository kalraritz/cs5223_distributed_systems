package model;

public enum Direction {
	NORTH,
	SOUTH,
	WEST,
	EAST,
	NOMOVE
}
