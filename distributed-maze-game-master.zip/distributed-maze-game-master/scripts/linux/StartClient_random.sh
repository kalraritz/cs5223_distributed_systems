#!/bin/sh

set CLASSPATH=.

java client.ClientController localhost 30030 Server r
pause
