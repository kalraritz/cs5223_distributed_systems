#!/bin/sh

export CLASSPATH=.

rmiregistry 30030& 
java server.ServerController 10 1000 30030 Server

pause
