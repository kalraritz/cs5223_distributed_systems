#!/bin/sh

export CLASSPATH=.

java client.ClientController localhost 30030 Server x
